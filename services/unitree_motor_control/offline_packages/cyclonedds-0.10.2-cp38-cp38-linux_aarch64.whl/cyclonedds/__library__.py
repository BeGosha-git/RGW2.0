in_wheel = False
library_path = '/home/unitree/cyclonedds_ws/install/cyclonedds/lib/libddsc.so'